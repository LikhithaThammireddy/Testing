package demo;
        import static org.hamcrest.Matchers.is;
		import java.util.HashMap;
		import java.util.UUID;
        import org.testng.Assert;
	    import org.testng.annotations.Test;
		import io.restassured.RestAssured;
		import io.restassured.path.json.JsonPath;
		import io.restassured.response.Response;


		public class Log4JExample extends TestBase {
			HashMap<String,String> map=new HashMap <String,String>();
			UUID uuid=UUID.randomUUID();
			int id;
			Response response;
			JsonPath jsonPath;
			
			@Test(priority=0)
			public void createPayLoad() {
				map.put("name","likhitha");
				map.put("email", uuid+ "@gmail.com");
				map.put("gender", "male");
				map.put("status", "active");

				RestAssured.baseURI="https://gorest.co.in/";
				RestAssured.basePath="/public/v2/users";
				logger.info("Payload created");
			}
			
			@Test(priority=1)
			public void createResource() {
				response=RestAssured
						.given()
						   .contentType("application/json")
						   .body(map)
						   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
						 .when()
						   .post()
						 .then()
						   
				             .extract().response();
				logger.info("Resource created");
				jsonPath=response.jsonPath(); 
				 id=jsonPath.get("id");
				System.out.println(id);
				String name=jsonPath.get("name");
				System.out.println(name);
				System.out.println(" ");
				
				
		    }
			
				@Test(priority=2)
				public void verifyResource() {
					RestAssured
					.given()
					   .contentType("application/json")
					   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
					 .when()
					   .get("https://gorest.co.in/public/v2/users/"+id)
					 .then()
					   .statusCode(200);
					logger.info("Resource verified");
					   
					String name=jsonPath.get("name");
					System.out.println("likhitha is equal to:"+name);
					System.out.println(" ");
					
					Assert.assertTrue(jsonPath.get("name").equals("likhitha"));
					
			
		}
				@Test(priority=3)
				public void updateResource() {
					map.put("name","likhitha Reddy");
					map.put("email", uuid+ "@gmail.com");
					map.put("gender", "female");
					map.put("status", "active");

					RestAssured.baseURI="https://gorest.co.in/";
					RestAssured.basePath="/public/v2/users/"+id;
					logger.info("Payload updated");
				response=RestAssured
					.given()
					   .contentType("application/json")
					   .body(map)
					   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
					 .when()
					     .put()
					 .then()
					   .statusCode(200)
					    .assertThat()
					   .body("name", is("likhitha Reddy"))
				      .extract().response();
				logger.info("Resource updated");

				jsonPath=response.jsonPath();
				String name=jsonPath.get("name");
				System.out.println("likhitha is updated to :"+name);
				System.out.println(" ");
									}
				@Test(priority=4)
				public void deleteResource() {
					RestAssured.baseURI="https://gorest.co.in/";
					RestAssured.basePath="/public/v2/users/"+id;
					RestAssured
					.given()
					   .contentType("application/json")
					   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
					 .when()
					   .delete()
					 .then()
					   .statusCode(204);
					logger.info("Resource deleted");
					System.out.println(" ");
					   
				
		}}


