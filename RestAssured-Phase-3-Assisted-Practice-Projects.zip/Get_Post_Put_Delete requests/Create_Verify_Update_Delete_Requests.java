package demo;
    import static org.hamcrest.Matchers.is;
	import java.util.HashMap;
	import java.util.UUID;
	import org.testng.Assert;
	import org.testng.annotations.BeforeTest;
	import org.testng.annotations.Test;
	import io.restassured.RestAssured;
	import io.restassured.path.json.JsonPath;
	import io.restassured.response.Response;


	public class Create_Verify_Update_Delete_Requests {
		HashMap<String,String> map=new HashMap <String,String>();
		UUID uuid=UUID.randomUUID();
		int id;
		Response response;
		JsonPath jsonPath;
		
		@BeforeTest
		public void createPayLoad() {
			map.put("name","likhitha");
			map.put("email", uuid+ "@gmail.com");
			map.put("gender", "male");
			map.put("status", "active");

			RestAssured.baseURI="https://gorest.co.in/";
			RestAssured.basePath="/public/v2/users";
			
		}
		@Test(priority=0)
		public void createResource() {
			response=RestAssured
					.given()
					   .contentType("application/json")
					   .body(map)
					   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
					 .when()
					   .post()
					 .then()
					   .log().all()
			             .extract().response();
			jsonPath=response.jsonPath(); 
			 id=jsonPath.get("id");
			System.out.println(id);
	   
	    }
		
			@Test(priority=1)
			public void verifyResource() {
				RestAssured
				.given()
				   .contentType("application/json")
				   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
				 .when()
				   .get("https://gorest.co.in/public/v2/users/"+id)
				 .then()
				   .statusCode(200)
				   .log().all();
				String name=jsonPath.get("name");
				System.out.println(name);
				
				Assert.assertTrue(jsonPath.get("name").equals("likhitha"));
				
		
	}
			@Test(priority=2)
			public void updateResource() {
				map.put("name","likhitha Reddy");
				map.put("email", uuid+ "@gmail.com");
				map.put("gender", "female");
				map.put("status", "active");

				RestAssured.baseURI="https://gorest.co.in/";
				RestAssured.basePath="/public/v2/users/"+id;
			response=RestAssured
				.given()
				   .contentType("application/json")
				   .body(map)
				   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
				 .when()
				     .put()
				 .then()
				   .statusCode(200)
				   .log().all()
				   .assertThat()
				   .body("name", is("likhitha Reddy"))
			      .extract().response();
			jsonPath=response.jsonPath();
			String name=jsonPath.get("name");
			System.out.println(name);
				}
			@Test(priority=3)
			public void deleteResource() {
				RestAssured.baseURI="https://gorest.co.in/";
				RestAssured.basePath="/public/v2/users/"+id;
				RestAssured
				.given()
				   .contentType("application/json")
				   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
				 .when()
				   .delete()
				 .then()
				   .statusCode(204);
				   
			
	}}
