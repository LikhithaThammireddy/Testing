package demo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GetBearerToken {
	@Test
	public void verifyResourceResource() {
		RestAssured
		.given()
		   .contentType("application/json")
		   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
		 .when()
		   .get("https://gorest.co.in/public/v2/users/4495336")
		 .then()
		   .statusCode(200)
		   .log().all();
		
		

}}
