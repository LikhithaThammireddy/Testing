package demo;


	import java.util.HashMap;

import io.restassured.response.Response;
import org.junit.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

	public class VerifyMsgUsingJsonPath {
	HashMap<String,String> map=new HashMap <String,String>();
		
		@BeforeMethod
		public void createPayLoad() {
			map.put("name", "batmannn");
			map.put("email", "batman554466@gmail.com");
			map.put("gender", "male");
			map.put("status", "active");
			RestAssured.baseURI="https://gorest.co.in/";
			RestAssured.basePath="/public/v2/users/4495018";
		}
		@Test
		public void updateResource() {
			Response response=RestAssured
			.given()
			   .contentType("application/json")
			   .body(map)
			   .header("Authorization","Bearer 8f6deddeac5abc33e77180f60c8969537f50fc4b29c465540c40f8dd991fe23b")
			 .when()
			   .put()
			 .then()
			   .extract().response();
			  JsonPath jsonPath=response.jsonPath(); 
			 String actualOutput=jsonPath.get("name").toString();
			String expectedOutput="batmannn";
			 // Assert.assertTrue(jsonPath.get("name").toString().equals("batmannn"));
			 Assert.assertTrue(actualOutput.equals("batmannn"));
			 System.out.println(actualOutput);
			 System.out.println(expectedOutput);
			 }}
