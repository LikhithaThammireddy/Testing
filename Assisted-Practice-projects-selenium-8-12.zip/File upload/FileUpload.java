package demo;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {
	public static void main(String[] args) throws InterruptedException, IOException {
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.remove.bg/");
		//driver.findElement(By.xpath("(//button[contains(@class,'btn btn-primary btn-lg')])[1]")).click();
		driver.findElement(By.cssSelector("#page-content > div:nth-child(2) > div.flex.items-center.justify-center.overflow-x-clip > div > div > div > div.relative.group.flex.flex-col.gap-4.md\\:gap-8.max-w-md.mt-8.md\\:mt-28 > div.w-full.flex.flex-col.sm\\:justify-center.sm\\:items-center.sm\\:gap-8.sm\\:pt-36.sm\\:pb-16.rounded-4xl.bg-white.shadow-2xl > button")).click();
		Thread.sleep(4000);
	Runtime.getRuntime().exec("resources//Upload.exe");
}}
