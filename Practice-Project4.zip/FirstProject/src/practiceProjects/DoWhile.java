package practiceProjects;

public class DoWhile {
	public static void main (String[] args) {
		int i=0,n=10;
		do {
			System.out.println("Value is:"+i);
			i++;
		}
			
		while(i<=n);
	}}
