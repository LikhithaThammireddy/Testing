package practiceProjects;

public class For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for (i=0;i<=10;i++) {
			System.out.println("value of i:"+i);
					}
		}

	}


