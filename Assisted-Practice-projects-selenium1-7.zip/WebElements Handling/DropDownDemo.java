package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



import org.openqa.selenium.support.ui.Select;

public class DropDownDemo {

	public static void main(String[] args) {
		
		ChromeDriver driver=new ChromeDriver();
		//navigate to application
		driver.get("https://letcode.in/dropdowns");
	   // window maximize
		driver.manage().window().maximize();
	WebElement Languages=driver.findElement(By.id("lang"));
	Select select=new Select(Languages);
	select.selectByVisibleText("Java");
	
				
	}

}
