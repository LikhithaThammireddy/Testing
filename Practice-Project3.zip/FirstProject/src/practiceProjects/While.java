package practiceProjects;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<=5) 
		{
			System.out.println("value:"+i);
			i++;
			
		}

	}

}
