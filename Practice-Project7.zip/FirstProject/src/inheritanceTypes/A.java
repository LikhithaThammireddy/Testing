package inheritanceTypes;

public class A {
	public void methodA()
	   {
	     System.out.println("Inheritance types");
	   }}





