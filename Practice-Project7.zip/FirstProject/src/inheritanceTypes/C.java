package inheritanceTypes;

 class C extends B{
	public void methodC() {
		System.out.println("multilevel inheritance");
		
	}
	public static void main(String[]args) {
	C c =  new C();
	c.methodA();
	c.methodB();
	c.methodC();
		
	}

}
