package simplilearn.com.JunitDEmo;

public class Demo13 {
	@Fast
	public void myFastTest() {
		
	}

}
