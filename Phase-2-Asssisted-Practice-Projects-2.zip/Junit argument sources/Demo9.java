package simplilearn.com.JunitDEmo;

import org.junit.jupiter.params.ParameterizedTest;

import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.Assert.assertEquals;

public class Demo9 {
	@ParameterizedTest
	@CsvSource({"test, Test", "monday , MONDAY","july ,JULY"})
	public void test(String actual, String expected) {
		String actualValue=actual.toUpperCase();
		String expectedValue=actual.toUpperCase();
		assertEquals(actualValue,expectedValue);
		System.out.println(expectedValue);
		System.out.println(actualValue);
		
	}

}
