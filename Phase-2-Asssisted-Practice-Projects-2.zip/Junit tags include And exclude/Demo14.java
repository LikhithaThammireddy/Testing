package simplilearn.com.JunitDEmo;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.IncludeTags;
import org.junit.runner.RunWith;
@RunWith(JUnitPlatform.class)
@IncludeTags("Production")
public class Demo14 {
	@Tag("Production")
	@Tag("Development")
	@Test
	public void test1() {
		
	}
	@Test
	@Tag("Production")
	public void test2() {
		
	}
	@Test
	@Tag("Development")
	public void test3() {
		
	}
	
}
