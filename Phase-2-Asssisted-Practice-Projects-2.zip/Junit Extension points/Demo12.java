package simplilearn.com.JunitDEmo;

import java.lang.annotation.ElementType;
import java.util.EnumSet;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

public class Demo12 {
	@ParameterizedTest
	@EnumSource(value=ElementType.class,names= {"TYPE","FIELD","METHOD"})
	public void test1(ElementType et) {
		assertTrue(EnumSet.of(ElementType.TYPE,ElementType.FIELD,ElementType.METHOD).contains(et));
		
		/*
		 * System.out.println(ElementType.TYPE); System.out.println(ElementType.FIELD);
		 * System.out.println(ElementType.METHOD);
		 */
		 	}

}
