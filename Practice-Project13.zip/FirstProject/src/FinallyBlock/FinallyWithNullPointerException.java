package FinallyBlock;

public class FinallyWithNullPointerException {
	public static void main(String[] args) {
		int num1=0;
		int num2=100;
		try {
			System.out.println(num2/num1);
			}
		catch(NullPointerException e) //this block will execute if exception occurs in try block
		{  
			System.out.println("Exception handled");
			System.out.println(e);
		}
		finally {
			System.out.println("The execution of this block is always executed" );
		}
		System.out.println("end of the code");
	

	}


}
