package FinallyBlock;

public class FinallyWithoutException {
	public static void main(String[] args) {
		int num1=10;
		int num2=100;
		try {
			System.out.println(num2/num1);
			}
		catch(Exception e) //this block will execute if exception occurs in try block
		{  
			System.out.println("Exception handled");
			System.out.println(e);
		}
		finally {
			System.out.println("The execution of this block is always executed" );
		}
		System.out.println("end of the code");
	

	}

}
