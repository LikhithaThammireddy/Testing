package demo;

import org.testng.annotations.Test;

public class GroupingDemo {
	@Test(groups="Luxury Cars")
	public void Car1() {
		System.out.println("BMW");
		
	}
	@Test(groups="Car")
	
	public void Car2() {
		System.out.println("audi");
		
	}
	@Test(groups="Luxury Cars")
	
	public void Car3() {
		System.out.println("mercedes");
		
	}
	@Test(groups={"Luxury Cars","Car"})
	
	public void Car4() {
		System.out.println("toyota");
		
	}
	@Test(groups="Car")
	
	public void Car5() {
		System.out.println("honda");
		
	}
	@Test(groups="Car")
	
	public void Car6() {
		System.out.println("hundai");
		
	}

}
