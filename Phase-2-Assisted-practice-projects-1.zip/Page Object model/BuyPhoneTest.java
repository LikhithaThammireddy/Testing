package in.amazon.testscripts;


import java.util.ArrayList;

import org.junit.Assert;
import org.testng.annotations.Test;

import in.amazon.pages.AllMobileBrands;
import in.amazon.pages.ApplePhones;
import in.amazon.pages.BuyPhone;
import in.amazon.pages.LandingPage;
import in.amazon.pages.SignIn;

public class BuyPhoneTest extends BaseTest {
	
	@Test
	public void buyMobile() {
		LandingPage landingpage=new LandingPage(driver);
         landingpage.clickMobiles();
				
		AllMobileBrands allMobileBrands =new AllMobileBrands(driver);
		allMobileBrands.hoverMobilesAndAccessories();
		
		
		allMobileBrands.clickapple();
	
		
		
		ApplePhones applePhones=new ApplePhones(driver);
		applePhones.clickFirstMobile();
		
		   
		ArrayList<String> tabs=	new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		BuyPhone buyPhone=new BuyPhone(driver);
		buyPhone.clickbuyNowButton();
		
		
		SignIn signIn=new SignIn(driver);
		String expectedText= "Sign in";
		String actualText =signIn.getSignInText();
		Assert.assertEquals(actualText,expectedText);
		
	}
		
    }
	
	


