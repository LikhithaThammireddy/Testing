package in.amazon.testscripts;

import org.junit.Assert;
import org.testng.annotations.Test;

import in.amazon.pages.LandingPage;
import in.amazon.pages.SignIn;

public class VerifyErrorMessageTest extends BaseTest {
	
	@Test
	public void verifyErrorMsg()  {
		
		LandingPage landingpage=new LandingPage(driver);
         landingpage.hoverOverHelloSignInMenu();
         
         landingpage.clickSignInBtn();
         SignIn signIn=new SignIn(driver);
         signIn.enterEmail("batman445566@gmail.com");
         signIn.clickContinueButton();
         String exceptedErrmsg="We cannot find an account with that email address";
         String actualErrmsg=signIn.getErrMsg();
         Assert.assertEquals(exceptedErrmsg,actualErrmsg);
	
	

}
}
