package demo;

import java.time.Duration;

//import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ExplicitWaitDemo {
	ChromeDriver driver;

	
	@BeforeTest
	public void launchApplication() {
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
	        //navigate the application
	        driver.get("https://whitecircleschool.com/explicit-wait-demo1/");
		
	}
	@Test
	public void explicitWaitDemo() throws InterruptedException {
		//click on start button
        driver.findElement(By.id("start")). click();
        //expected output
       String expectedOutput="Hello World!";
      Thread.sleep(1000);
       //waiting
     //WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(60));
     // wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#finish > h4 ")));
       
       String actualOutput=driver.findElement(By.cssSelector("#finish > h4 ")).getText();
       Assert.assertEquals(expectedOutput, actualOutput);
    
}
	@AfterTest
	public void closeBrowser() {
    	driver.quit();
    	
    }
	

}
