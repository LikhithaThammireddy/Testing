package in.amazon.testscripts;

import java.io.IOException;

import org.junit.Assert;
import org.testng.annotations.Test;

import in.amazon.pages.LandingPage;
import in.amazon.pages.SignIn;
import utils.ReadExcel;

public class DDF extends BaseTest {
	@Test
		public void verifyErrorMsg() throws IOException  {
		//hover
			
			LandingPage landingpage=new LandingPage(driver);
	         landingpage.hoverOverHelloSignInMenu();
	         //click on sign in
	         
	         landingpage.clickSignInBtn();
	         
	         String[][] data =ReadExcel.getData("resources//TestData.xlsx","Sheet1");
	         for(int i=1;i<5;i++) {
	        String username=data[i][1];	 
	         
	         
	        //enter invalid username
	         SignIn signIn=new SignIn(driver);
	         signIn.enterEmail(username);
	         //click on continue
	         signIn.clickContinueButton();
	         
	         String exceptedErrmsg="We cannot find an account with that email address";
	         String actualErrmsg=signIn.getErrMsg();
	         Assert.assertEquals(exceptedErrmsg,actualErrmsg);
		
		

	}


	}
}
