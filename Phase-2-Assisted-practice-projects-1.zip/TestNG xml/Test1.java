package demo;

import org.testng.annotations.Test;

public class Test1 {
	@Test
	public void test() {
		System.out.println("hi");
		
	}
	

}
