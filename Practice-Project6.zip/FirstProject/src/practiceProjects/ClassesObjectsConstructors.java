package practiceProjects;
public class ClassesObjectsConstructors {
	String brand;
	String  color;
	int year;
	public ClassesObjectsConstructors() //Default Constructor
	{
		brand="mercedes";
		color="white";
		year=2021;
	}
    public ClassesObjectsConstructors(String brand,String color,int year)// parameterized Constructor
    {
       this.brand=brand;
		this.color=color;
		this.year=year;
	}
	public void display()   //Method Creation
	{
		System.out.println(" car brand :"+brand);
		System.out.println(" car color :"+color);
		System.out.println(" car year bought:"+year);
		System.out.println("  ");
		
	}

public static void main(String[] args) {
		
		
ClassesObjectsConstructors c1=new ClassesObjectsConstructors("Toyota","Red",2023);//object created as c1
	c1.display();
ClassesObjectsConstructors c2= new ClassesObjectsConstructors("Audi","Black",2022);//object created as c2
	c2.display();
ClassesObjectsConstructors c3= new ClassesObjectsConstructors();//object created as c3
	c3.display();

		
	}



}
