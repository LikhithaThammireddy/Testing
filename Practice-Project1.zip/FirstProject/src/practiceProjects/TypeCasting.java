package practiceProjects;

public class TypeCasting {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//implicit conversion
		int num=10;
		double num1=num;
		System.out.println("value of num1 is"+num1);
		
		//Explicit conversion
		double num2= 7.6;
		int num3=(int)num2;
	       System.out.println("value of num3 is:"+num3);

	}

}



