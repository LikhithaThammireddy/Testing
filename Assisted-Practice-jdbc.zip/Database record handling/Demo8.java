package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo8 {
	 public static void main(String[] args) throws ClassNotFoundException, SQLException{
			String dbUrl="jdbc:mysql://localhost:3306/animated_movies";
			String username="root";
			String password="Likhi@123sql";
			String query= "Delete from movies where title='Finding nemo';";
			Connection con = null;

			try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(dbUrl,username,password);//connection to db
			Statement stmt=con.createStatement();//execute the query
			stmt.execute(query);//after execute update the result
			
			}
			catch(Exception e) {
				System.out.println(e.getMessage());//e.printStackTrace();
			}
			finally {
							con.close();
			}
		}



			


}



