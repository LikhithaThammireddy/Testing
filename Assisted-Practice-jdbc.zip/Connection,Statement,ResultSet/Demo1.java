package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String dbUrl="jdbc:mysql://localhost:3306/animated_movies";
		String username="root";
		String password="Likhi@123sql";
		String query="select * from movies;";
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(dbUrl,username,password);//connection
		Statement stmt=con.createStatement();//statement
		ResultSet rs=stmt.executeQuery(query);//result set
		while(rs.next()) {
			System.out.print("Title :"+rs.getString("title") + "\t");
			System.out.print("Genre:"+rs.getString("Genre") + "\t");
			System.out.print("Director:"+rs.getString("Director") + "\t");
			System.out.println("Year:"+rs.getString("Year") + "\t");
			
		}
		

	}

}
