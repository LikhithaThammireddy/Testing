package practiceProjects;

public class AccessModifiers {
	public void publicMethod() {
 	   System.out.println("This is public Method");
    }
	protected void protectedMethod() {
	   System.out.println("This is protected Method");
 }
	private void privateMethod() {
	   System.out.println("This is private Method");
 }
	void defaultMethod() {
	   System.out.println("This is public Method");
 }
public static void main(String[] args) {
	AccessModifiers m= new AccessModifiers();
	m.publicMethod();// public method can be accessed everywhere in the program
	m.protectedMethod();//protected method can be accessed within in the same package and also access subclasses in different packages
	m.privateMethod();//private Method can be accessed only within the class
	m.defaultMethod();// default method can be accessed only within the package
	
}
}
