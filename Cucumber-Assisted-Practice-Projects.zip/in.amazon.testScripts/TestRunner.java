package in.amazon.testSteps;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

public class TestRunner {
@CucumberOptions(
			features="Features//buy_books.feature",
			glue="in.amazon.testSteps"
			//dryRun=true
			//tags= "@BuyProduct"
			//multiple tags
			//tags="@Product_Purchase or @LoginFunctionality"
			//tags="@TC_101 or TC_102"
			
			)
	
	public class testRunner extends AbstractTestNGCucumberTests
	{
	
	}
}
