package in.amazon.testSteps;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import org.testng.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


	public class BuyMobilePhoneSteps extends Driver {
				@Given("a user is on the landing page")
		public void a_user_is_on_the_landing_page() {
			//long form

			/*
			 * String
			 * expectedTitle="Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in"
			 * ; String actualTitle=driver.getTitle();
			 * Assert.assertEquals(expectedTitle,actualTitle);
			 */	
					//short form
			 assertTrue(driver.getTitle().equals("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in"));
		}

		@When("he clicks on the mobiles on the naigation bar")
		public void he_clicks_on_the_mobiles_on_the_naigation_bar() {
			
	         landingpage.clickMobiles();
			
		    
		}

		@When("he over the point on Mobiles & Acessories")
		public void he_over_the_point_on_mobiles_acessories() {
			
			allMobileBrands.hoverMobilesAndAccessories();
			
			
			
		    
		}

		@When("he clicks on apple in the submenu")
		public void he_clicks_on_apple_in_the_submenu() {
						allMobileBrands.clickapple();
		    
		}

		@When("he clicks the second available phone")
		public void he_clicks_the_second_available_phone() throws InterruptedException {
			
			applePhones.clickSecondMobile();
			
		    
		}

		@When("he switches focus on the new tab")
		public void he_switches_focus_on_the_new_tab() {
			ArrayList<String> tabs=	new ArrayList<>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));

		    
		}

		@When("he clicks on the buy now button")
		public void he_clicks_on_the_buy_now_button() {
						buyPhone.clickbuyNowButton();
		    
		}

		@Then("he able to purchase the mobile successfully.")
		public void he_able_to_purchase_the_mobile_successfully() {
		String expectedText= "Sign in";
			String actualText =signIn.getSignInText();
			Assert.assertEquals(actualText,expectedText);
		   
		}
	}



