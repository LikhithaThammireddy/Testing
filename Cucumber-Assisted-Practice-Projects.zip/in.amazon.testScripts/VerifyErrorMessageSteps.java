package in.amazon.testSteps;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class VerifyErrorMessageSteps extends Driver {
	@Given("a user is on  landing page")
	public void a_user_is_on_landing_page() {
		//long form

		/*
		 * String
		 * expectedTitle="Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in"
		 * ; String actualTitle=driver.getTitle();
		 * Assert.assertEquals(expectedTitle,actualTitle);
		 */	
				//short form
		 assertTrue(driver.getTitle().equals("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in"));
	}

		
	
	@When("he overs the Hello sign-in menu")
	public void he_overs_the_hello_sign_in_menu() {

		
         landingpage.hoverOverHelloSignInMenu();
         
	   
	}

	@When("he clicks on the sign in button in sub-menu")
	public void he_clicks_on_the_sign_in_button_in_sub_menu() {
		landingpage.clickSignInBtn();
	    
	}

	@When("he enters the invalid email address in the text-box")
	public void he_enters_the_invalid_email_address_in_the_text_box() {
        signIn.enterEmail("batman445566@gmail.com");
	    
	}

	@When("he clicks on the continue button")
	public void he_clicks_on_the_continue_button() {
		
		signIn.clickContinueButton();
	    
	}

	@Then("he must see the error message -{string}")
	public void he_must_see_the_error_message(String string) {
		String expectedErrmsg="We cannot find an account with that email address";
		
        String actualErrmsg=signIn.getErrMsg();
      Assert.assertEquals(expectedErrmsg,actualErrmsg);
      
	   
	}

 @When("he enters the invalid email address {string} in the emailText")
 public void he_enters_the_invalid_email_address_in_the_email_text(String string) 
  {
	 signIn.enterEmail(string);
	 
		
  }
	 
	 
	
    
    	
 }


